package com.example.ulink.repository

data class RequestLogin(
    val id : String,
    val password : String
)