package com.example.ulink.CalendarRecycler

class CalendarDayData (
    val day : String, // day
    val check : Boolean, // now_month
    val date : Int, // sunday_check & firstLine_check
    val today : Boolean // today_check
)