package com.example.ulink.timetable

import com.example.ulink.repository.TimeTable

interface TimeTableAddListener {
    fun onAdded(timeTable :TimeTable)
}