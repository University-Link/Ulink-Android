package com.example.ulink.CalendarRecycler

import android.util.Log
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.ulink.R
import com.example.ulink.ResponseNoticeData
import com.example.ulink.ScheduleRecycler.CalendarSmallScheduleAdapter
import com.example.ulink.ScheduleRecycler.nowDay
import com.example.ulink.ScheduleRecycler.nowMonth
import com.example.ulink.ScheduleRecycler.nowYear

class CalendarViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView) {

    val rv = itemView.findViewById<RecyclerView>(R.id.rv_smallschedule)

    fun bind(dayData : CalendarDayData, serverData : MutableList<ResponseNoticeData>, serverData2 : HashMap<String, List<ResponseNoticeData>>
    , calendarData: CalendarData, index : Int){

        Log.d("tag", dayData.toString())
        Log.d("tag index", index.toString())
        calendarDayColorCheck(dayData, itemView)
        calendarAlpha(dayData, itemView)

        var prevEmptyIndex = calendarPreviousIndexCheck(calendarData, index)

        var lastindex = endDay[calendarData.month - 1]

        var lastEmpty = index+lastindex

        var checkYear : String = popupYearCheck(calendarData.year, calendarData.month, adapterPosition, index, lastEmpty).toString()
        var itemMonth = popupMonthCheck(adapterPosition, index, lastEmpty, calendarData.month)
        var itemDay = popupDayCheck(adapterPosition, index, lastEmpty, prevEmptyIndex)

        var checkMonth : String = ""
        var checkDay : String = ""
        if(itemMonth<10) checkMonth = "0$itemMonth"
        if(itemDay <10) checkDay = "0$itemDay"

        var positionDate = checkYear+"-"+checkMonth+"-"+checkDay


        val mAdapter =  CalendarSmallScheduleAdapter()
        if (serverData2.get(positionDate)== null){
            mAdapter.list = arrayListOf()
        } else{
            mAdapter.list = serverData2.get(positionDate)!!
        }
        rv.adapter = mAdapter

//      지금 시간을 구하고 position밖에 없어
//      현재 달 알 수 있지 -> 지금 포지션으로 2020-07-03?
//      그 string을 이용해서 hashma에서 그날의 데이터를 뽑아온다


    }
}
