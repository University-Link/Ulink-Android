package com.example.ulink.TimeTableDirectRecycler

data class TimeTableDirectData(
    var day : Int,
    var start_time : String,
    var end_time : String
)