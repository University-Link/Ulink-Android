package com.example.ulink.repository

data class RequestGetClassNotice(
    val jwt : String,
    val idx : String
)