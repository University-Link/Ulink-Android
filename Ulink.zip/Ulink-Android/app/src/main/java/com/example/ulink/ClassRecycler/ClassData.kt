package com.example.ulink.ClassRecycler

data class ClassData(
    val ClassImage : String,
    val ClassName : String,
    val now : Int,
    val total : Int,
    val count : String
)