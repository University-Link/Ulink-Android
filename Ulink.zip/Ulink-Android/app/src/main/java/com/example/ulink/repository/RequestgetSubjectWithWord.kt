package com.example.ulink.repository

data class RequestgetSubjectWithWord (
    val token : String,
    val name : String
)