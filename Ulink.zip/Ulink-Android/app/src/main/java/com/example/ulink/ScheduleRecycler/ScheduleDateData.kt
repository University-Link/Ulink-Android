package com.example.ulink.ScheduleRecycler

data class ScheduleDateData(
    var day : Int,
    var date : String,
    var dday : String
)