package com.example.ulink.repository

data class RequestGetSubjectList(
    val token : String
)