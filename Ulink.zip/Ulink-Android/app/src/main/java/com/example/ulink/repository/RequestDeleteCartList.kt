package com.example.ulink.repository

data class RequestDeleteCartList(
    var semester : String
)