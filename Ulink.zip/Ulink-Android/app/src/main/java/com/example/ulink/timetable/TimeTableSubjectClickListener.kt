package com.example.ulink.timetable

import com.example.ulink.repository.Subject

interface TimeTableSubjectClickListener {
    fun onClick(subject : Subject)
}