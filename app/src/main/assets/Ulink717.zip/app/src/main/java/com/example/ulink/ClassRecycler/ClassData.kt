package com.example.ulink.ClassRecycler

data class ClassData(
    val subjectIdx : Int,
    val name : String,
    val color : Int,
    val total : Int,
    val current : Int
)