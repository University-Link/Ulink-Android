package com.example.ulink.CalendarRecycler

data class CalendarData(
        val year : Int,
        val month : Int
)