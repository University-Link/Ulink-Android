package com.example.ulink.repository

data class RequestaddCartList(
    val semester : String,
    val subjectIdx : Int
)