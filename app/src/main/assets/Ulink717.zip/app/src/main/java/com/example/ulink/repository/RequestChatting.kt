package com.example.ulink.repository

data class RequestChatting(
    val jwt : String
)