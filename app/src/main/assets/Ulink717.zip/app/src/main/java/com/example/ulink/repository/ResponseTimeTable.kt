package com.example.ulink.repository

data class ResponseTimeTable (
        val status : Int
)