package com.example.ulink.repository

data class ResponsedeleteMainTimeTable(
    val status: Int
)