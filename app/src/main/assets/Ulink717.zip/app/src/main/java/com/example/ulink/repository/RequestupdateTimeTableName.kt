package com.example.ulink.repository

data class RequestupdateTimeTableName(
    val name : String
)