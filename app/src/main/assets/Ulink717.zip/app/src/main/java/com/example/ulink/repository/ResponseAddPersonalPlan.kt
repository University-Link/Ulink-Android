package com.example.ulink.repository

data class ResponseAddPersonalPlan(
        val status : Int,
        val success : Boolean,
        val message : String
)