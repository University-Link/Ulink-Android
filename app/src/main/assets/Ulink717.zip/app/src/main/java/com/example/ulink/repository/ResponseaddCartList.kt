package com.example.ulink.repository

data class ResponseaddCartList(
    val status : Int,
    val success : Boolean,
    val message : String
)