package com.example.ulink.ExperimentNoticeRecycler

data class ExperimentNoticeData (
    val StartDate : Int,
    val EndDate : Int,
    val ClassName : String,
    val Class : String
)