package com.example.ulink.repository

data class RequestDeleteCartList(
    val semester : String
)