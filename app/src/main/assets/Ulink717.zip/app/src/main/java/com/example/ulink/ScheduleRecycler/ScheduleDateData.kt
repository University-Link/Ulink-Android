package com.example.ulink.ScheduleRecycler

data class ScheduleDateData(
    var day : String,
    var date : String,
    var dday : Long
)