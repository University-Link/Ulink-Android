package com.example.ulink.repository

data class ResponseRegisterNotice (
    val status: Int,
    val success: Boolean,
    val message: String
)