package com.example.ulink.TimeTable_Search_Recycler

data class SearchData(
    val search_result:String,
    val search_type : String
)