package com.example.ulink.repository

data class RequestAddSchoolPlan (
        var subjectIdx : Int,
        var color : Int,
        var scheduleIdx : Int
)