package com.example.ulink.repository

data class RequestAddTimeTable (
        val semester : String,
        val name: String
)